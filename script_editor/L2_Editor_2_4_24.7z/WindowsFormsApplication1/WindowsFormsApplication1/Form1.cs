﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;
using System.Globalization;


namespace WindowsFormsApplication1
{

    public partial class Form1 : Form
    {
        private enum CtrlMode
        {
            Saturn_JP_Mode,
            PSX_US_Mode
        }

        public textPointer_Type[] textPointerArray;
        public uint numTextPointers;
        public String header = "";
        private CtrlMode ctrl_code_mode = CtrlMode.PSX_US_Mode;

        private const string commandSectionStart = "<Command_Section>";        
        private const string commandSectionEnd = "</Command_Section>";
        private const string textSectionStart = "<Text_Section>";
        private const string textSectionEnd = "</Text_Section>";

        public uint G_Ctrl_Option   = 0;
        public uint G_Ctrl_Portrait = 0;
        public uint G_Ctrl_Item = 0;
        public uint G_Ctrl_Animation = 0;
        public uint G_Ctrl_Pause = 0;

        public Form1()
        {
            InitializeComponent();

            listBox1.BackColor = System.Drawing.Color.AliceBlue;
            listBox1.ForeColor = System.Drawing.Color.Black;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        //Load File Button
        private void button1_Click(object sender, EventArgs e)
        {
            numTextPointers = 0;
            textPointerArray = new textPointer_Type[10];

            listBox1.Items.Clear();

            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                InitialDirectory = @"C:\",
                Title = "Browse Text Files",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = "txt",
                Filter = "txt files (*.txt)|*.txt",
                FilterIndex = 2,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                header = "";
                String line;
                StreamReader sr = new StreamReader(openFileDialog1.FileName, System.Text.Encoding.UTF8);

                //Read in the Header
                line = sr.ReadLine();
                while(sr != null){

                    if (line.Contains(commandSectionStart))
                    {
                        break;
                    }
                    else
                    {
                        header += line;
                        header += "\n";
                    }

                    //Read next line
                    line = sr.ReadLine();
                }

                //Read in the Command Section
                int x = 0;
                line = sr.ReadLine();
                while(sr != null){

                    if (line.Contains("Num_Text_Pointers:"))
                    {
                        string[] subStrings = line.Split(' ');
                        numTextPointers = Convert.ToUInt32(subStrings[1], 16);
                        Array.Resize(ref textPointerArray, (int)numTextPointers);
                        for (int i = 0; i < (int)numTextPointers; i++)
                        {
                            textPointerArray[i] = new textPointer_Type();
                        }
                    }
                    else if (line.Contains("Text_Pointer_"))
                    {
                        string[] subStrings = line.Split(' ');
                        textPointerArray[x].pointerNum = x+1;
                        textPointerArray[x].ScriptOffset = Convert.ToUInt32(subStrings[2], 16);
                        textPointerArray[x].DlgTextOffset = Convert.ToUInt32(subStrings[4], 16);
                        x++;
                    }
                    else if(line.Contains(commandSectionEnd))
                        break;

                    //Read next line
                    line = sr.ReadLine();
                }

                //Look for Start of Text Section
                line = sr.ReadLine();
                while (sr != null)
                {
                    if (line.Contains(textSectionStart))
                        break;
                    line = sr.ReadLine();
                }
                line = "";

                //Read in the Dialog Text Section
                for(x = 0; x < (int)numTextPointers; x++)
                {
                    textPointerArray[x].numDialogs = 0;   //second row text disappearing?

                    //Read Dlg Header (Contains Label, Offset, Size)
                    textPointerArray[x].dlgHdr = "";
                    while (line != "Text_Start")
                    {
                        if (line == null)
                            break;
                        line = sr.ReadLine();
                        if (line == "Text_Start")
                            break;
                        else if(line.Contains("Label")){
                            //Grab the Text# Label for the List Box
                            //This will be tiedto the dialog listing to be displayed
                            textPointerArray[x].lkupStr = line.Substring(7, line.Length - 7);
                            listBox1.Items.Add(textPointerArray[x].lkupStr);
                        }
                        textPointerArray[x].dlgHdr += line;
                        textPointerArray[x].dlgHdr += "\n";
                    }

                    //Read Dialog Box Data
                    int numSeq1000 = 0;
                    uint lastCtrlCode = 0;
                    bool nextPassEndsDlg = false;
                    bool enableSwap = false;
                    line = sr.ReadLine();
                    while(line != "Text_End")
                    {
                        DialogData tmp = new DialogData();

                        if(line == null)
                            break;

                        //Count # of Dialog Boxes for this section of text & Decode Ctrl Codes
                        if(line.Contains("Control_Code")){
                            string[] subStrings = line.Split(' ');
                            uint ctrlCode = Convert.ToUInt32(subStrings[1], 16);
                            tmp.type = ctrlCode;

                            if (ctrl_code_mode == CtrlMode.Saturn_JP_Mode)
                            {
                                G_Ctrl_Option   = 0x5000;
                                G_Ctrl_Portrait = 0xC000;
                                G_Ctrl_Item = 0xB000;
                                G_Ctrl_Animation = 0xD000;
                                G_Ctrl_Pause = 0xE000;

                                ////////////////////////
                                // Saturn Decode Mode //
                                ////////////////////////
                                uint ctrlCodeTest = 0xF000 & ctrlCode;
                                if (ctrlCodeTest == 0x1000)
                                    tmp.text = "(newline)";
                                else if ((ctrlCodeTest == 0x2000) || (ctrlCodeTest == 0x7000) || (ctrlCodeTest == 0x8000))
                                    tmp.text = "(Press_button,auto-clear box)";
                                else if (ctrlCodeTest == 0x3000)
                                {
                                    uint ctrlCodeTest2 = ctrlCode & 0xFFF;
                                    tmp.text = "(Print left half text UTF8: 0x" + ctrlCodeTest2.ToString("X3") + ")";
                                }
                                else if (ctrlCodeTest == 0x5000)
                                {
                                    //Either 2 or 3 Selections.  Dialogs are always the last part of a text section
                                    uint ctrlCodeTest2 = ctrlCode & 0xF;
                                    tmp.text = "(Dlog Selection " + ctrlCodeTest2 + ")";
                                }
                                else if (ctrlCodeTest == 0x9000)
                                    tmp.text = "(Space)";
                                else if (ctrlCodeTest == 0xB000)
                                    tmp.text = "(Item_Print)";
                                else if ((ctrlCodeTest == 0xC000) || (ctrlCodeTest == 0xF000))
                                    tmp.text = "(Left Portrait)";
                                else if (ctrlCodeTest == 0xD000)
                                    tmp.text = "(Animation?)";
                                else if (ctrlCodeTest == 0xE000)
                                {
                                    uint ctrlCodeTest2 = ctrlCode & 0xFFF;
                                    tmp.text = "(Text Pause 0x" + ctrlCodeTest2.ToString("X3") + ")";
                                }
                                else
                                    tmp.text = "(ERROR)";
                            }
                            else
                            {
                                /////////////////////
                                // PSX Decode Mode //
                                /////////////////////
                                G_Ctrl_Option = 0x4000;
                                G_Ctrl_Portrait = 0xB000;
                                G_Ctrl_Item = 0xA000;
                                G_Ctrl_Animation = 0xC000;
                                G_Ctrl_Pause = 0xD000;

                                uint ctrlCodeTest = 0xF000 & ctrlCode;
                                if (ctrlCodeTest == 0x1000)
                                    tmp.text = "(newline)";
                                else if ((ctrlCodeTest == 0x2000) || (ctrlCodeTest == 0x6000))
                                    tmp.text = "(Press_button,auto-clear box)";
                                else if (ctrlCodeTest == 0x4000)
                                {
                                    //Either 2 or 3 Selections.  Dialogs are always the last part of a text section
                                    uint ctrlCodeTest2 = ctrlCode & 0xF;
                                    tmp.text = "(Dlog Selection " + ctrlCodeTest2 + ")";
                                }
                                else if (ctrlCodeTest == 0xA000)
                                    tmp.text = "(Item_Print)";
                                else if (ctrlCodeTest == 0xB000)
                                    tmp.text = "(Left Portrait)";
                                else if (ctrlCodeTest == 0xC000)
                                    tmp.text = "(Animation?)";
                                else if (ctrlCodeTest == 0xD000)
                                {
                                    uint ctrlCodeTest2 = ctrlCode & 0xFFF;
                                    tmp.text = "(Text Pause 0x" + ctrlCodeTest2.ToString("X3") + ")";
                                }
                                else
                                    tmp.text = "(ERROR)";
                            }

                            if((lastCtrlCode == 0x1000) && (tmp.text.Contains("Pause")))
                            {
                                int index = (textPointerArray[x].dlogData.Count-1);
                                tmp.associatedDlg = textPointerArray[x].dlogData[index].associatedDlg;
                                enableSwap = true;
                            }
                            else
                                tmp.associatedDlg = textPointerArray[x].numDialogs;
                            

                            //Dialog Box full test
                            if( (ctrlCode == 0x2000) || (ctrlCode == 0x6000) || (ctrlCode == 0x8000) ){
                                
                                numSeq1000 = 0;
                                textPointerArray[x].dlogData.Add(tmp);

                                //Post-Pause Check
                                line = sr.ReadLine();
                                if ((line != null) && (line.Contains("Text Pause 0x")))
                                {
                                    nextPassEndsDlg = true;    
                                }
                                else
                                {
                                    textPointerArray[x].numDialogs++;
                                }
                                lastCtrlCode = ctrlCode;
                                continue;
                            }
                            else if( (ctrlCode == 0x1000)){
                                numSeq1000++;
                                if(numSeq1000 == 4)  /* Should not happen */
                                    textPointerArray[x].numDialogs++;
                            }

                            lastCtrlCode = ctrlCode;
                        }
                        else if (line[0] == '\"')
                        {
                            line = Regex.Replace(line, "^\"|\"$", ""); //String  remove first and last " character
                            tmp.type = 0;
                            tmp.text = line;
                            tmp.associatedDlg = textPointerArray[x].numDialogs;
                            lastCtrlCode = 0;
                        }
                        textPointerArray[x].dlogData.Add(tmp);
                        if (enableSwap == true)
                        {
                            int lastIndex = textPointerArray[x].dlogData.Count - 1;
                            int prevIndex = textPointerArray[x].dlogData.Count - 2;
                            DialogData data = textPointerArray[x].dlogData[prevIndex];
                            textPointerArray[x].dlogData[prevIndex] = textPointerArray[x].dlogData[lastIndex];
                            textPointerArray[x].dlogData[lastIndex] = data;
                            enableSwap = false;
                        }

                        if (nextPassEndsDlg == true)
                        {
                            textPointerArray[x].numDialogs++;
                            nextPassEndsDlg = false;
                        }

                        //Read Next Line
                        line = sr.ReadLine();
                    }
                    if(lastCtrlCode != 0x2000)
                        textPointerArray[x].numDialogs++;
                }                
                sr.Close();

                
                

            }
        }

        

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private int activeTxtPtr = -1;
        private int activeTxtPtrDlgIndex = -1;

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
                return;

            // Get the currently selected item in the ListBox.
            string curItem = listBox1.SelectedItem.ToString();

            for (int x = 0; x < numTextPointers; x++)
            {
                if (textPointerArray[x].lkupStr == curItem)
                {
                    activeTxtPtr = x;
                    activeTxtPtrDlgIndex = 0;

                    updateCurrentDialog(activeTxtPtrDlgIndex);
                    break;
                }
            }

        }


        //On saturn pause always preceeds a newline.  On psx, pause happens after newline

        private void updateCurrentDialog(int dialogNum)
        {
            int i = 0;
            int lfnum = 0;
            int animationCounter = 0;
            int pressButtonDetected = 0;
            int line1TextSel = 0;
            int line2TextSel = 0;
            int line3TextSel = 0;

            //Init Gui
            optionsText.Text = "No";
            textBox1.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            textBox10.Text = "";
            textBox11.Text = "";
            textBox13.Text = "";
            textBox10.Enabled = false;
            textBox11.Enabled = false;
            textBox13.Enabled = false;
            checkBox1.Checked = false;  //LF1
            checkBox2.Checked = false;  //LF2
            checkBox3.Checked = false;  //LF3
            checkBox4.Checked = false;  //PushButton
            portraitText.Text = "";
            itemBox.Text = "";
            animationText1.Text = "";
            animationText2.Text = "";
            checkPause1.Checked = false;
            checkPause2.Checked = false;
            checkPause3.Checked = false;
            checkPause4.Checked = false;
            checkPause5.Checked = false;
            checkPause6.Checked = false;
            checkPause7.Checked = false;
            textPause1.Text = "";
            textPause2.Text = "";
            textPause3.Text = "";
            textPause4.Text = "";
            textPause5.Text = "";
            textPause6.Text = "";
            textPause7.Text = "";

            /* Display the dialog# in the current set */
            int totalDlogs = textPointerArray[activeTxtPtr].numDialogs;
            dlogNum.Text = (dialogNum+1).ToString() + "/" + totalDlogs.ToString();

            if (ctrl_code_mode == CtrlMode.PSX_US_Mode)
            {
                G_Ctrl_Option = 0x4000;
                G_Ctrl_Portrait = 0xB000;
                G_Ctrl_Item = 0xA000;
                G_Ctrl_Animation = 0xC000;
                G_Ctrl_Pause = 0xD000;
            }
            else
            {
                G_Ctrl_Option = 0x5000;
                G_Ctrl_Portrait = 0xC000;
                G_Ctrl_Item = 0xB000;
                G_Ctrl_Animation = 0xD000;
                G_Ctrl_Pause = 0xE000;
            }

            //Locate start of target dialog data
            while ((i < (textPointerArray[activeTxtPtr].dlogData.Count())) &&
                   (textPointerArray[activeTxtPtr].dlogData[i].associatedDlg != dialogNum) )
            {
                i++;
            }

            //Fill in dialog with information from the dlogData record
            while ((i < (textPointerArray[activeTxtPtr].dlogData.Count() )) &&
                   (textPointerArray[activeTxtPtr].dlogData[i].associatedDlg == dialogNum) )
            {
                uint typeTest = textPointerArray[activeTxtPtr].dlogData[i].type & 0xF000;

                //Line of Text
                if (typeTest == 0)
                {
                    if(lfnum == 0){
                        if(line1TextSel == 0)
                            textBox1.Text = textPointerArray[activeTxtPtr].dlogData[i].text;
                        else
                            textBox10.Text = textPointerArray[activeTxtPtr].dlogData[i].text;
                    }
                    else if(lfnum == 1){
                        if(line2TextSel == 0)
                            textBox4.Text = textPointerArray[activeTxtPtr].dlogData[i].text;
                        else
                            textBox11.Text = textPointerArray[activeTxtPtr].dlogData[i].text;
                    }
                    else{
                        if(line3TextSel == 0)
                            textBox5.Text = textPointerArray[activeTxtPtr].dlogData[i].text;
                        else
                            textBox13.Text = textPointerArray[activeTxtPtr].dlogData[i].text;
              
                    }
                }

                ////////////////
                //Control Code//
                ////////////////
                else if (typeTest == 0x1000)
                {
                    if (lfnum == 0)
                    {
                        checkBox1.Checked = true;
                        lfnum++;
                    }
                    else if (lfnum == 1)
                    {
                        checkBox2.Checked = true;
                        lfnum++;
                    }
                    else
                    {
                        checkBox3.Checked = true;
                        lfnum++;
                    }
                }
                else if ((typeTest == 0x2000) || (typeTest == 0x6000) || (typeTest == 0x8000))
                {
                    checkBox4.Checked = true;
                    pressButtonDetected = 1;
                }
                else if (typeTest == G_Ctrl_Option)
                {
                    uint optNum = textPointerArray[activeTxtPtr].dlogData[i].type & 0xF;
                    optionsText.Text = "0x" + optNum.ToString("X3");
                }
                else if (typeTest == G_Ctrl_Portrait)
                {
                    portraitText.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                }
                else if (typeTest == G_Ctrl_Item)
                {
                    itemBox.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                }
                else if (typeTest == G_Ctrl_Animation)
                {
                    if (animationCounter == 0)
                    {
                        animationText1.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                        animationCounter++;
                    }
                    else if (animationCounter == 1)
                    {
                        animationText2.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                        animationCounter++;
                    }
                }
                else if (typeTest == G_Ctrl_Pause)
                {
                    if ((pressButtonDetected == 1) || (lfnum >= 3))
                    {
                        checkPause7.Checked = true;
                        textPause7.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                    }
                    else
                    {
                        if((lfnum == 0) && (checkPause1.Checked == false))
                        {
                            checkPause1.Checked = true;
                            textPause1.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                            line1TextSel = 1;
                            textBox10.Enabled = true;
                        }
                        else if ((lfnum == 0) && (checkPause4.Checked == false))
                        {
                            checkPause4.Checked = true;
                            textPause4.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                        }

                        else if ((lfnum == 1) && (checkPause2.Checked == false))
                        {
                            checkPause2.Checked = true;
                            textPause2.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                            line2TextSel = 1;
                            textBox11.Enabled = true;
                        }
                        else if ((lfnum == 1) && (checkPause5.Checked == false))
                        {
                            checkPause5.Checked = true;
                            textPause5.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                        }

                        else if ((lfnum == 2) && (checkPause3.Checked == false))
                        {
                            checkPause3.Checked = true;
                            textPause3.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                            line3TextSel = 1;
                            textBox13.Enabled = true;
                        }
                        else if ((lfnum == 2) && (checkPause6.Checked == false))
                        {
                            checkPause6.Checked = true;
                            textPause6.Text = "0x" + (textPointerArray[activeTxtPtr].dlogData[i].type & 0xFFF).ToString("X3");
                        }


                    }
                }
                else
                {
                    ;// MessageBox.Show("Unknown Control Code" + textPointerArray[activeTxtPtr].dlogData[i].type);
                }

                i++;
            }

        }




        /***************************************/
        /* Delete, Insert Before, Insert After */
        /***************************************/


        //Delete Button
        private void delete_button_Click(object sender, EventArgs e)
        {
            int dialogNum = activeTxtPtrDlgIndex;

            if ((activeTxtPtr >= 0) && (activeTxtPtrDlgIndex >= 0))
            {
                if (textPointerArray[activeTxtPtr].numDialogs <= 1)
                {
                   // string message = "Error";
                   // string title = "Cant delete, only 1 entry";
                   // MessageBox.Show(this,message, title,MessageBoxButtons.OK);
                    //System.Windows.Forms.MessageBox.Show(message, title);
                    //Do nothing
                    ;// MessageBox.Show(this, "Cant delete, only 1 entry", "Error", MessageBoxButtons.OK);
                }
                else if (textPointerArray[activeTxtPtr].dlogData.Count() > 0)
                {
                    //Locate start of target dialog data
                    int i = 0;
                    while ((i < (textPointerArray[activeTxtPtr].dlogData.Count())) &&
                           (textPointerArray[activeTxtPtr].dlogData[i].associatedDlg != dialogNum))
                    {
                        i++;
                    }

                    //Remove data
                    while ((i < (textPointerArray[activeTxtPtr].dlogData.Count())) &&
                           (textPointerArray[activeTxtPtr].dlogData[i].associatedDlg == dialogNum))
                    {
                        textPointerArray[activeTxtPtr].dlogData.RemoveAt(i);
                    }

                    //Update associated dialog #s for rest of data
                    while (i < (textPointerArray[activeTxtPtr].dlogData.Count()))
                    {
                        textPointerArray[activeTxtPtr].dlogData[i].associatedDlg -= 1;
                        i++;
                    }

                    //Update dialog box  -- works from top down , not down up....
                    //if (textPointerArray[activeTxtPtr].dlogData.Count() > 0) // should not trigger...
                    //{
                        if (dialogNum > (textPointerArray[activeTxtPtr].dlogData[i - 1].associatedDlg))
                            activeTxtPtrDlgIndex--;
                    //}
                    textPointerArray[activeTxtPtr].numDialogs--;
                    updateCurrentDialog(activeTxtPtrDlgIndex);
                }
            }
        }

        private void insert_after_Click(object sender, EventArgs e)
        {
            int dialogNum = activeTxtPtrDlgIndex;
            int insertIndex = 0;
            int savedAssociatedDialog = 0;

            if ((activeTxtPtr >= 0) && (activeTxtPtrDlgIndex >= 0))
            {
                if (textPointerArray[activeTxtPtr].dlogData.Count() > 0)
                {
                    //Locate start of target dialog data
                    int i = 0;
                    while ((i < (textPointerArray[activeTxtPtr].dlogData.Count())) &&
                           (textPointerArray[activeTxtPtr].dlogData[i].associatedDlg != dialogNum))
                    {
                        i++;
                    }

                    //Get to the first index after the current dialog
                    while ((i < (textPointerArray[activeTxtPtr].dlogData.Count())) &&
                           (textPointerArray[activeTxtPtr].dlogData[i].associatedDlg == dialogNum))
                    {
                        i++;
                    }

                    //Save the index to insert at as well as the associated dialog #
                    insertIndex = i;
                    if (i == textPointerArray[activeTxtPtr].dlogData.Count())
                    {
                        //Adding a dialog at the end
                        savedAssociatedDialog = textPointerArray[activeTxtPtr].dlogData[i-1].associatedDlg;
                        savedAssociatedDialog++;
                    }
                    else
                    {
                        savedAssociatedDialog = textPointerArray[activeTxtPtr].dlogData[i].associatedDlg;
                    }               

                    //Update associated dialog #s for rest of data
                    while (i < (textPointerArray[activeTxtPtr].dlogData.Count()))
                    {
                        textPointerArray[activeTxtPtr].dlogData[i].associatedDlg++;
                        i++;
                    }

                    //Insert a blank dialog
                    DialogData newDlgItem = new DialogData();
                    newDlgItem.associatedDlg = savedAssociatedDialog;
                    newDlgItem.text = "";
                    newDlgItem.type = 0;
                    textPointerArray[activeTxtPtr].dlogData.Insert(insertIndex, newDlgItem);

                    //Update dialog box
                    textPointerArray[activeTxtPtr].numDialogs++;
                    activeTxtPtrDlgIndex = savedAssociatedDialog;
                    updateCurrentDialog(activeTxtPtrDlgIndex);
                }
            }
        }

        private void insert_before_Click(object sender, EventArgs e)
        {
            int dialogNum = activeTxtPtrDlgIndex;
            int insertIndex = 0;
            int savedAssociatedDialog = 0;

            if ((activeTxtPtr >= 0) && (activeTxtPtrDlgIndex >= 0))
            {
                if (textPointerArray[activeTxtPtr].dlogData.Count() > 0)
                {
                    //Locate start of target dialog data
                    if (dialogNum <= 0)
                    {
                        insertIndex = 0;
                    }
                    else
                    {
                        //Get to the first index before the current dialog
                        int i = 0;
                        while ((i < (textPointerArray[activeTxtPtr].dlogData.Count())) &&
                               (textPointerArray[activeTxtPtr].dlogData[i].associatedDlg != (dialogNum-1)))
                        {
                            i++;
                        }
                        insertIndex = i;
                    }
                    savedAssociatedDialog = textPointerArray[activeTxtPtr].dlogData[insertIndex].associatedDlg;

                    //Insert a blank dialog
                    DialogData newDlgItem = new DialogData();
                    if(insertIndex == 0)
                        newDlgItem.associatedDlg = 0;
                    else
                        newDlgItem.associatedDlg = dialogNum-1;
                    newDlgItem.text = "";
                    newDlgItem.type = 0;
                    textPointerArray[activeTxtPtr].dlogData.Insert(insertIndex, newDlgItem);



                    //Get to the first index after the current dialog and incr the associated dlogs
                    int y = insertIndex+1;
                    while (y < (textPointerArray[activeTxtPtr].dlogData.Count()))
                    {
                        textPointerArray[activeTxtPtr].dlogData[y].associatedDlg++; 
                        y++;
                    }

                    //Update dialog box
                    textPointerArray[activeTxtPtr].numDialogs++;
                    activeTxtPtrDlgIndex = savedAssociatedDialog;
                    updateCurrentDialog(activeTxtPtrDlgIndex);
                }
            }
        }






        /*****************************************************/
        /* Navigation - Previous and Next Dialog Box Buttons */
        /*****************************************************/

        //Previous Button
        private void prev_button_Click(object sender, EventArgs e)
        {
            if (activeTxtPtr < 0)
                return;

            if(saveDialogChanges(activeTxtPtrDlgIndex) < 0)
                return;

            if ((activeTxtPtr >= 0) && (activeTxtPtrDlgIndex > 0))
            {
                activeTxtPtrDlgIndex--;
                updateCurrentDialog(activeTxtPtrDlgIndex);
            }
        }

        //Next Button
        private void next_button_Click(object sender, EventArgs e)
        {
            if (activeTxtPtr < 0)
                return;

            if(saveDialogChanges(activeTxtPtrDlgIndex) < 0)
                return;

            if ((activeTxtPtr >= 0) && (activeTxtPtrDlgIndex < (textPointerArray[activeTxtPtr].numDialogs - 1)))
            {
                activeTxtPtrDlgIndex++;

                updateCurrentDialog(activeTxtPtrDlgIndex);
            }
        }


        private void createCtrlCode(int insertIndex, uint code, String associatedText, int associatedDlg)
        {
            DialogData newDlgItem = new DialogData();
            newDlgItem.associatedDlg = associatedDlg;
            newDlgItem.text = associatedText;
            newDlgItem.type = code;
            textPointerArray[activeTxtPtr].dlogData.Insert(insertIndex, newDlgItem);
        }


        //Verifies that valid hex numbers with or without 0x are entered in the text boxes
        private int verifyNumericEntries()
        {
            uint testVal;
            String testStr = null;
            int rval = 0;

            /* Portrait */
            portraitText.BackColor = SystemColors.Info;
            if ((portraitText.TextLength >= 3) && (portraitText.Text[0] == '0') && ((portraitText.Text[1] == 'X') || (portraitText.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = portraitText.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    portraitText.BackColor = Color.Red;
                    rval = - 1;
                }
            }
            else if ((portraitText.TextLength > 0) && (!uint.TryParse(portraitText.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                portraitText.BackColor = Color.Red;
                rval = -1;
            }


            /* Animation 1 and 2 */
            animationText1.BackColor = SystemColors.Info;
            animationText2.BackColor = SystemColors.Info;
            if ((animationText1.TextLength >= 3) && (animationText1.Text[0] == '0') && ((animationText1.Text[1] == 'X') || (animationText1.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = animationText1.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    animationText1.BackColor = Color.Red;
                    rval = -1;
                }
            }
            else if ((animationText1.TextLength > 0) && (!uint.TryParse(animationText1.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                animationText1.BackColor = Color.Red;
                rval = -1;
            }

            if ((animationText2.TextLength >= 3) && (animationText2.Text[0] == '0') && ((animationText2.Text[1] == 'X') || (animationText2.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = animationText2.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    animationText2.BackColor = Color.Red;
                    rval = -1;
                }
            }
            else if ((animationText2.TextLength > 0) && (!uint.TryParse(animationText2.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                animationText2.BackColor = Color.Red;
                rval = -1;
            }
    
            
            /* Options */
            optionsText.BackColor = SystemColors.Info;
            if(optionsText.Text.Contains("No"))
                optionsText.BackColor = SystemColors.Info;
            else if ((optionsText.TextLength >= 3) && (optionsText.Text[0] == '0') && ((optionsText.Text[1] == 'X') || (optionsText.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = optionsText.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    optionsText.BackColor = Color.Red;
                    rval = -1;
                }
            }
            else if ((optionsText.TextLength > 0) && (!uint.TryParse(optionsText.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                optionsText.BackColor = Color.Red;
                rval = -1;
            }
            
            /* Item */
            int validItemDetected = 0;
            itemBox.BackColor = SystemColors.Info;
            if ((itemBox.TextLength >= 3) && (itemBox.Text[0] == '0') && ((itemBox.Text[1] == 'X') || (itemBox.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = itemBox.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    itemBox.BackColor = Color.Red;
                    rval = -1;
                }
                else
                    validItemDetected = 1;
            }
            else if ((itemBox.TextLength > 0) && (!uint.TryParse(itemBox.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                itemBox.BackColor = Color.Red;
                rval = -1;
            }
            else if ((itemBox.TextLength > 0) && (uint.TryParse(itemBox.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                validItemDetected = 1;
            }
            if (validItemDetected == 1)
            {
                /* Make sure first line of text is one or more spaces */
                textBox1.BackColor = SystemColors.Info;
                if(textBox1.TextLength == 0)
                    textBox1.Text = " ";
                else if(textBox1.TextLength > 0){
                    for(int z = 0; z < textBox1.TextLength; z++){
                        if(textBox1.Text[z] != ' ')
                        {
                            textBox1.BackColor = Color.Red;
                            rval = -1;
                        }
                    }
                }

                /* Should not have a second string in the first line */
                if (textBox10.TextLength > 0)
                {
                    textBox10.BackColor = Color.Red;
                    rval = -1;
                }
                else
                    textBox10.BackColor = SystemColors.Info;
            }

            //Pause Boxes (7)
            textPause1.BackColor = SystemColors.Info;
            if ((textPause1.TextLength >= 3) && (textPause1.Text[0] == '0') && ((textPause1.Text[1] == 'X') || (textPause1.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = textPause1.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    textPause1.BackColor = Color.Red;
                    rval = -1;
                }
            }
            else if ((textPause1.TextLength > 0) && (!uint.TryParse(textPause1.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                textPause1.BackColor = Color.Red;
                rval = -1;
            }

            textPause2.BackColor = SystemColors.Info;
            if ((textPause2.TextLength >= 3) && (textPause2.Text[0] == '0') && ((textPause2.Text[1] == 'X') || (textPause2.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = textPause2.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    textPause2.BackColor = Color.Red;
                    rval = -1;
                }
            }
            else if ((textPause2.TextLength > 0) && (!uint.TryParse(textPause2.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                textPause2.BackColor = Color.Red;
                rval = -1;
            }

            textPause3.BackColor = SystemColors.Info;
            if ((textPause3.TextLength >= 3) && (textPause3.Text[0] == '0') && ((textPause3.Text[1] == 'X') || (textPause3.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = textPause3.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    textPause3.BackColor = Color.Red;
                    rval = -1;
                }
            }
            else if ((textPause3.TextLength > 0) && (!uint.TryParse(textPause3.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                textPause3.BackColor = Color.Red;
                rval = -1;
            }

            textPause4.BackColor = SystemColors.Info;
            if ((textPause4.TextLength >= 3) && (textPause4.Text[0] == '0') && ((textPause4.Text[1] == 'X') || (textPause4.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = textPause4.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    textPause4.BackColor = Color.Red;
                    rval = -1;
                }
            }
            else if ((textPause4.TextLength > 0) && (!uint.TryParse(textPause4.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                textPause4.BackColor = Color.Red;
                rval = -1;
            }

            textPause5.BackColor = SystemColors.Info;
            if ((textPause5.TextLength >= 3) && (textPause5.Text[0] == '0') && ((textPause5.Text[1] == 'X') || (textPause5.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = textPause5.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    textPause5.BackColor = Color.Red;
                    rval = -1;
                }
            }
            else if ((textPause5.TextLength > 0) && (!uint.TryParse(textPause5.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                textPause5.BackColor = Color.Red;
                rval = -1;
            }

            textPause6.BackColor = SystemColors.Info;
            if ((textPause6.TextLength >= 3) && (textPause6.Text[0] == '0') && ((textPause6.Text[1] == 'X') || (textPause6.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = textPause6.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    textPause6.BackColor = Color.Red;
                    rval = -1;
                }
            }
            else if ((textPause6.TextLength > 0) && (!uint.TryParse(textPause6.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                textPause6.BackColor = Color.Red;
                rval = -1;
            }

            textPause7.BackColor = SystemColors.Info;
            if ((textPause7.TextLength >= 3) && (textPause7.Text[0] == '0') && ((textPause7.Text[1] == 'X') || (textPause7.Text[1] == 'x')))
            {
                /* Need to remove 0x to do the test */
                testStr = textPause7.Text.Substring(2);
                if (!uint.TryParse(testStr, NumberStyles.HexNumber, null, out testVal))
                {
                    textPause7.BackColor = Color.Red;
                    rval = -1;
                }
            }
            else if ((textPause7.TextLength > 0) && (!uint.TryParse(textPause7.Text, NumberStyles.HexNumber, null, out testVal)))
            {
                textPause7.BackColor = Color.Red;
                rval = -1;
            }

            return rval;
        }


        private int saveDialogChanges(int dialogNum)
        {
            int insertIndex = 0;
            int initialInsertLocation = 0;

            if (activeTxtPtr < 0)
                return -1;

            //Verify numbers are numbers
            if( verifyNumericEntries() < 0)
                return -1;


            //Get to the first index of the dialog
            int i = 0;
            while ((i < (textPointerArray[activeTxtPtr].dlogData.Count())) &&
                    (textPointerArray[activeTxtPtr].dlogData[i].associatedDlg != dialogNum))
            {
                i++;
            }
            insertIndex = i;
            initialInsertLocation = insertIndex;

            //Delete the existing dialog data
            while ((i < (textPointerArray[activeTxtPtr].dlogData.Count())) &&
                    (textPointerArray[activeTxtPtr].dlogData[i].associatedDlg == dialogNum))
            {
                textPointerArray[activeTxtPtr].dlogData.RemoveAt(i);
            }

            /////////////////////////////////////
            //Save the new dialog data in-place//
            /////////////////////////////////////

            //Portrait
            if (portraitText.TextLength > 0)
            {
                uint portraitValueStripped = Convert.ToUInt32(portraitText.Text, 16);
                uint portraitValue = G_Ctrl_Portrait | portraitValueStripped;
                createCtrlCode(insertIndex, portraitValue, "(Left Portrait)", dialogNum);
                insertIndex++;
            }

            //Animations
            if (animationText1.TextLength > 0)
            {

                uint animationValueStripped = Convert.ToUInt32(animationText1.Text, 16);
                uint animationValue = G_Ctrl_Animation | animationValueStripped;
                createCtrlCode(insertIndex, animationValue, "(Animation?)", dialogNum);
                insertIndex++;

                if (animationText2.TextLength > 0)
                {
                    animationValueStripped = Convert.ToUInt32(animationText2.Text, 16);
                    animationValue = G_Ctrl_Animation | animationValueStripped;
                    createCtrlCode(insertIndex, animationValue, "(Animation?)", dialogNum);
                    insertIndex++;
                }
            }

            //Options
            if (!optionsText.Text.Contains("No"))
            {
                uint optionsValueStripped = Convert.ToUInt32(optionsText.Text, 16);
                uint optionValue = G_Ctrl_Option | optionsValueStripped;
                createCtrlCode(insertIndex, optionValue, "(Dlog Selection " + optionsValueStripped + ")", dialogNum);
                insertIndex++;
            }
                
            //Item            
            if(itemBox.TextLength > 0){
                uint itemValueStripped = Convert.ToUInt32(itemBox.Text, 16);
                uint itemValue = G_Ctrl_Item | itemValueStripped;
                createCtrlCode(insertIndex, itemValue, "(Item_Print)", dialogNum);
                insertIndex++;
            }

            
            ////////////
            // Line 1 //
            ////////////

            //Line 1-1
            if(textBox1.TextLength > 0){
                DialogData newDlgItem = new DialogData();
                newDlgItem.associatedDlg = dialogNum;
                newDlgItem.text = textBox1.Text;
                newDlgItem.type = 0;
                textPointerArray[activeTxtPtr].dlogData.Insert(insertIndex, newDlgItem);
                insertIndex++;
            }

            //L1 Mid-Pause (Checkbox and text)
            if (checkPause1.Checked)
            {
                uint pauseValueStripped = Convert.ToUInt32(textPause1.Text, 16);
                uint pauseValue = G_Ctrl_Pause | pauseValueStripped;
                createCtrlCode(insertIndex, pauseValue, "(Text Pause 0x" + pauseValueStripped.ToString("X3") + ")", dialogNum);
                insertIndex++;
            }

            //Line 1-2
            if (textBox10.TextLength > 0)
            {
                DialogData newDlgItem = new DialogData();
                newDlgItem.associatedDlg = dialogNum;
                newDlgItem.text = textBox10.Text;
                newDlgItem.type = 0;
                textPointerArray[activeTxtPtr].dlogData.Insert(insertIndex, newDlgItem);
                insertIndex++;
            }

            //L1 Post-Pause (Checkbox and text)
            if (checkPause4.Checked)
            {
                uint pauseValueStripped = Convert.ToUInt32(textPause4.Text, 16);
                uint pauseValue = G_Ctrl_Pause | pauseValueStripped;
                createCtrlCode(insertIndex, pauseValue, "(Text Pause 0x" + pauseValueStripped.ToString("X3") + ")", dialogNum);
                insertIndex++;
            }

            //L1 Linefeed
            if(checkBox1.Checked){
                createCtrlCode(insertIndex, 0x1000, "(newline)",dialogNum);
                insertIndex++;
            }

            ////////////
            // Line 2 //
            ////////////

            //Line 2-1
            if (textBox4.TextLength > 0)
            {
                DialogData newDlgItem = new DialogData();
                newDlgItem.associatedDlg = dialogNum;
                newDlgItem.text = textBox4.Text;
                newDlgItem.type = 0;
                textPointerArray[activeTxtPtr].dlogData.Insert(insertIndex, newDlgItem);
                insertIndex++;
            }

            //L2 Mid-Pause (Checkbox and text)
            if (checkPause2.Checked)
            {
                uint pauseValueStripped = Convert.ToUInt32(textPause2.Text, 16);
                uint pauseValue = G_Ctrl_Pause | pauseValueStripped;
                createCtrlCode(insertIndex, pauseValue, "(Text Pause 0x" + pauseValueStripped.ToString("X3") + ")", dialogNum);
                insertIndex++;
            }

            //Line 2-2
            if (textBox11.TextLength > 0)
            {
                DialogData newDlgItem = new DialogData();
                newDlgItem.associatedDlg = dialogNum;
                newDlgItem.text = textBox11.Text;
                newDlgItem.type = 0;
                textPointerArray[activeTxtPtr].dlogData.Insert(insertIndex, newDlgItem);
                insertIndex++;
            }

            //L2 Post-Pause (Checkbox and text)
            if (checkPause5.Checked)
            {
                uint pauseValueStripped = Convert.ToUInt32(textPause5.Text, 16);
                uint pauseValue = G_Ctrl_Pause | pauseValueStripped;
                createCtrlCode(insertIndex, pauseValue, "(Text Pause 0x" + pauseValueStripped.ToString("X3") + ")", dialogNum);
                insertIndex++;
            }

            //L2 Linefeed
            if (checkBox2.Checked)
            {
                createCtrlCode(insertIndex, 0x1000, "(newline)", dialogNum);
                insertIndex++;
            }

            ////////////
            // Line 3 //
            ////////////

            //Line 3-1
            if (textBox5.TextLength > 0)
            {
                DialogData newDlgItem = new DialogData();
                newDlgItem.associatedDlg = dialogNum;
                newDlgItem.text = textBox5.Text;
                newDlgItem.type = 0;
                textPointerArray[activeTxtPtr].dlogData.Insert(insertIndex, newDlgItem);
                insertIndex++;
            }

            //L3 Mid-Pause (Checkbox and text)
            if (checkPause3.Checked)
            {
                uint pauseValueStripped = Convert.ToUInt32(textPause3.Text, 16);
                uint pauseValue = G_Ctrl_Pause | pauseValueStripped;
                createCtrlCode(insertIndex, pauseValue, "(Text Pause 0x" + pauseValueStripped.ToString("X3") + ")", dialogNum);
                insertIndex++;
            }

            //Line 3-2
            if (textBox13.TextLength > 0)
            {
                DialogData newDlgItem = new DialogData();
                newDlgItem.associatedDlg = dialogNum;
                newDlgItem.text = textBox13.Text;
                newDlgItem.type = 0;
                textPointerArray[activeTxtPtr].dlogData.Insert(insertIndex, newDlgItem);
                insertIndex++;
            }

            //L3 Post-Pause (Checkbox and text)
            if (checkPause6.Checked)
            {
                uint pauseValueStripped = Convert.ToUInt32(textPause6.Text, 16);
                uint pauseValue = G_Ctrl_Pause | pauseValueStripped;
                createCtrlCode(insertIndex, pauseValue, "(Text Pause 0x" + pauseValueStripped.ToString("X3") + ")", dialogNum);
                insertIndex++;
            }

            //L3 Linefeed
            if (checkBox3.Checked)
            {
                createCtrlCode(insertIndex, 0x1000, "(newline)", dialogNum);
                insertIndex++;
            }

            //Press Button
            if (checkBox4.Checked)
            {
                createCtrlCode(insertIndex, 0x2000, "(Press_button,auto-clear box)", dialogNum);
                insertIndex++;
            }

            //Post-Pause(Checkbox and text)
            if (checkPause7.Checked)
            {
                uint pauseValueStripped = Convert.ToUInt32(textPause7.Text, 16);
                uint pauseValue = G_Ctrl_Pause | pauseValueStripped;
                createCtrlCode(insertIndex, pauseValue, "(Text Pause 0x" + pauseValueStripped.ToString("X3") + ")", dialogNum);
                insertIndex++;
            }

            //Add a dummy entry if nothing was found
            if (insertIndex == initialInsertLocation)
            {
                DialogData newDlgItem = new DialogData();
                newDlgItem.associatedDlg = dialogNum;
                newDlgItem.text = "";
                newDlgItem.type = 0;
                textPointerArray[activeTxtPtr].dlogData.Insert(insertIndex, newDlgItem);
                insertIndex++;
            }

            return 0;
        }




        //Save Script Button
        private void save_button_Click(object sender, EventArgs e)
        {
            int x;

            if (activeTxtPtr < 0)
                return;

            if (activeTxtPtrDlgIndex >= 0)
            {
                if (saveDialogChanges(activeTxtPtrDlgIndex) < 0)
                    return;
            }

            string str = "Test";
            SaveFileDialog SaveScript = new SaveFileDialog();
            SaveScript.Title = "Save Lunar 2 Script File";
            //SaveScript.CheckFileExists = true;
            //SaveScript.CheckPathExists = true;
            SaveScript.DefaultExt = "txt";
            SaveScript.Filter = "L2 Script files (*.txt)|*.txt|All files (*.*)|*.*";
            SaveScript.FilterIndex = 2;
            SaveScript.RestoreDirectory = true;
            SaveScript.ShowDialog();
//            if (SaveScript.ShowDialog() == DialogResult.OK)
            {
                str = SaveScript.FileName;
            }
            StreamWriter w = new StreamWriter(str, false, Encoding.UTF8);

            //Write File Header
            w.Write(header);

            //Write <Command_Section>
            w.WriteLine(commandSectionStart);
            w.WriteLine();

            //Write Command Data
            w.Write("Num_Text_Pointers: 0x{0}",numTextPointers.ToString("X"));
            w.WriteLine();

            for(x=0; x < numTextPointers; x++){
                //Text_Pointer_0001: ScriptOffset 0x00000020 DlgTextOffset 0x00000058
                w.WriteLine("\tText_Pointer_{0}: ScriptOffset 0x{1} DlgTextOffset 0x{2}",
                    textPointerArray[x].pointerNum.ToString("D4"), textPointerArray[x].ScriptOffset.ToString("X8"), textPointerArray[x].DlgTextOffset.ToString("X8"));
            }

            //Write </Command_Section>
            w.WriteLine(commandSectionEnd);
            w.WriteLine();

            //Write <Text_Section>
            w.WriteLine(textSectionStart);
            for(x=0; x< numTextPointers; x++){
                w.Write(textPointerArray[x].dlgHdr);

                w.WriteLine("Text_Start");
                for (int y = 0; y < textPointerArray[x].dlogData.Count; y++)
                {
                    if (textPointerArray[x].dlogData.ElementAt(y).type == 0)
                    {
                        //Text
                        w.WriteLine("\"" + textPointerArray[x].dlogData.ElementAt(y).text + "\"");
                    }
                    else
                    {
                        //Control Code
                        w.WriteLine("Control_Code 0x{0} {1}", 
                            textPointerArray[x].dlogData.ElementAt(y).type.ToString("X4"), textPointerArray[x].dlogData.ElementAt(y).text);
                    }
                }
                w.WriteLine("Text_End");
            }
            w.WriteLine(textSectionEnd);

            //Write </Text_Section>

            /*
            Label: Text 12
            Offset: 0x372
            Size: 0x48 bytes

            Text_Start
            Control_Code 0xB2C5 (Left Portrait 0xB2C5)
            "Hiro! Bust a move, I think we"
            Control_Code 0x1000 (newline)
            "lost 'em!"
            Control_Code 0x1000 (newline)
            Control_Code 0x2000 (Press_button,auto-clear box)
            Control_Code 0xB005 (Left Portrait 0xB005)
            "WaAaAaAahh--!!"
            Control_Code 0x1000 (newline)
            Text_End
            */

            w.Close();
        }


        //Radio button group to determine whether to use US or PSX Decoding Scheme for Control Codes
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (((RadioButton)sender).Checked == true)
                ctrl_code_mode = CtrlMode.Saturn_JP_Mode;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (((RadioButton)sender).Checked == true)
                ctrl_code_mode = CtrlMode.PSX_US_Mode;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }




        /*************************************/
        /* Bitmap Dialog Box Render Routines */
        /*************************************/


        /* getWidth - Used for text preview on screen */
        static int getWidth(int asciiValue)
        {

            int[] widthArray = {5, 1, 5, 8, 7, 11, 11, 2, 4, 4, 7, 5, 2, 4, 2, 4, 
                                6, 5, 7, 6, 7, 6, 6, 7, 6, 6, 2, 2, 8, 9, 8, 5,
                                14, 9, 7, 7, 7, 7, 7, 8, 9, 3, 5, 8, 7, 11, 9, 7,
                                7, 7, 8, 8, 7, 9, 9, 13, 9, 9, 7, 3, 13, 3, 15, 13,
                                2, 6, 7, 5, 7, 5, 6 /*f*/, 7, 7, 3, 3, 7, 3, 11, 7, 6,
                                7, 7, 5, 5, 4, 7, 7, 11, 7, 7, 6 /*z*/, 5, 1, 5, 8, 5};

            if (asciiValue < 0)
                return 0;

            if (asciiValue <= (0x7F - 0x20))
                return widthArray[asciiValue];

            return 16;
        }



        public void DrawLineInt(Bitmap bmp, int color_type, int tile_position)
        {
            Pen penColor = null;
            if (color_type == 0)
                penColor = new Pen(Color.Red, 3);
            else
                penColor = new Pen(Color.Yellow, 3);

            int x1 = (16 * tile_position);  //technically i think 15 works
            int y1 = 0;
            int x2 = (16 * tile_position);
            int y2 = 64;
            // Draw line to screen.
            using (var graphics = Graphics.FromImage(bmp))
            {
                graphics.DrawLine(penColor, x1, y1, x2, y2);
            }
        }

        public String Textstr = "";
        public String Textstr2 = "";
        public String Textstr3 = "";

        private void PictureBox1_Paint(object sender, PaintEventArgs e)
        {
            /* 16*14 wide (Maybe 16*15 wide works), 3 rows high */
            Bitmap tmpBmp = new Bitmap(@"C:\\share\\background.png");//(960,64);
            Graphics gg = Graphics.FromImage(tmpBmp);

            Font fnt = new Font("Arial", 10);

            // Create a local version of the graphics object for the PictureBox.
            Graphics g = e.Graphics;
/*
            // Draw a string on the PictureBox.
            g.DrawString("This is a diagonal line drawn on the control",
                fnt, System.Drawing.Brushes.Blue, new Point(30, 30));
            // Draw a line in the PictureBox.
            g.DrawLine(System.Drawing.Pens.Red, pictureBox1.Left, pictureBox1.Top,
                pictureBox1.Right, pictureBox1.Bottom);
*/

            int width = 16;   //This is variable once vwf implemented
            int height = 16;

            // Create a Bitmap object from a file.
            Image sourceImage = Image.FromFile(@"C:\\share\\L2_font_final.bmp");

//          String Textstr = "!//\"#$%&'()*+,-./0!1234@ABCDEPQRabcpqrs";


            for (int z = 0; z < 3; z++)
            {
                int num, dstX, dstY;
                String lclString;
                dstX = 0;

                if(z == 0){
                    lclString = Textstr;
                    dstY = 0;
                }
                else if (z == 1)
                {
                    lclString = Textstr2;
                    dstY = 16 + 4;
                }
                else
                {
                    lclString = Textstr3;
                    dstY = 32 + 8;
                }
                num = lclString.Length;

                int cnt = 0;
                while (cnt < num)
                {
                    int xpixel_topleft = 0;
                    int ypixel_topleft = 0;

                    char test = lclString[cnt];

                    //Account for the fact that the bitmap starts at ascii value 0x20
                    int asciiValue = (int)test - 0x20;

                    if (asciiValue < 0x10)
                    {
                        ypixel_topleft = 0;
                        xpixel_topleft = (asciiValue * 16);
                    }
                    else if (asciiValue < 0x20) /* Ascii 0 to ? */
                    {
                        ypixel_topleft = 16;
                        xpixel_topleft = ((asciiValue - 0x10) * 16);
                    }
                    else if (asciiValue < 0x30) /* Ascii @ to O */
                    {
                        ypixel_topleft = 32;
                        xpixel_topleft = ((asciiValue - 0x20) * 16);
                    }
                    else if (asciiValue < 0x40)  /* Ascii P to Z plus some misc */
                    {
                        ypixel_topleft = 48;
                        xpixel_topleft = ((asciiValue - 0x30) * 16);
                    }
                    else if (asciiValue < 0x50) /* Ascii ' then a,b,c, ... to o */
                    {
                        ypixel_topleft = 64;
                        xpixel_topleft = ((asciiValue - 0x40) * 16);
                    }
                    else if (asciiValue < 0x60)  /* Ascii p to z, quotes, and other misc */
                    {
                        ypixel_topleft = 80;
                        xpixel_topleft = ((asciiValue - 0x50) * 16);
                    }
                    else
                    {
                        ypixel_topleft = 96;
                        xpixel_topleft = ((asciiValue - 0x60) * 16);
                    }

                    // Draw a portion of the source image.  (lefttop x-coord, lefttop y-coord, width, height)
                    // 0,  16 = 0
                    // 16, 16 = 1
                    // 0,  32 = @
                    // 16, 32 = A
                    Rectangle sourceRect = new Rectangle(xpixel_topleft, ypixel_topleft, width, height);
                    Rectangle destRect = new Rectangle(dstX, dstY, width, height);
                    gg.DrawImage(sourceImage, destRect, sourceRect, GraphicsUnit.Pixel);

                    //                Bitmap bmpGood = new Bitmap(300, 300);
                    //               Graphics gg = Graphics.FromImage(bmpGood);
                    //               g.DrawImage(sourceImage, xpixel_topleft, ypixel_topleft, width, height);

                    //                dstX += 16;
                    int value = getWidth(asciiValue);
                    dstX += value;

                    if (((asciiValue + 0x20) == 'f') || ((asciiValue + 0x20) == ' '))
                        ;
                    else
                        dstX += 1;

                    cnt++;
                }
            }
            DrawLineInt(tmpBmp, 1, 14);
            DrawLineInt(tmpBmp, 0, 15);
            this.pictureBox1.Image = tmpBmp;
            this.pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
        }






        /**************/
        /* Text Boxes */
        /**************/

        //Line 1
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //HERE
            Textstr = textBox1.Text + textBox10.Text;
            if (Textstr.Length > 0)
                checkBox1.Checked = true;
            else
                checkBox1.Checked = false;
            pictureBox1.Refresh();
        }
        
        //Line 2
        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            Textstr2 = textBox4.Text + textBox11.Text;
            if (Textstr2.Length > 0)
                checkBox2.Checked = true;
            else
                checkBox2.Checked = false;
            pictureBox1.Refresh();
        }

        //Line 3
        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            Textstr3 = textBox5.Text + textBox13.Text;
            if (Textstr3.Length > 0)
                checkBox3.Checked = true;
            else
                checkBox3.Checked = false;
            pictureBox1.Refresh();
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            Textstr = textBox1.Text + textBox10.Text;
            if (Textstr.Length > 0)
                checkBox1.Checked = true;
            else
                checkBox1.Checked = false;
            pictureBox1.Refresh();
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
            Textstr2 = textBox4.Text + textBox11.Text;
            if (Textstr2.Length > 0)
                checkBox2.Checked = true;
            else
                checkBox2.Checked = false;
            pictureBox1.Refresh();
        }

        private void textBox13_TextChanged(object sender, EventArgs e)
        {
            Textstr3 = textBox5.Text + textBox13.Text;
            if (Textstr3.Length > 0)
                checkBox3.Checked = true;
            else
                checkBox3.Checked = false;
            pictureBox1.Refresh();
        }

        private void checkPause1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPause1.Checked == true)
            {
                textPause1.Enabled = true;
                textBox10.Enabled = true;
            }
            else
            {
                textPause1.Enabled = false;
                textBox10.Enabled = false;
            }
        }

        private void checkPause2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPause2.Checked == true)
            {
                textPause2.Enabled = true;
                textBox11.Enabled = true;
            }
            else
            {
                textPause2.Enabled = false;
                textBox11.Enabled = false;
            }
        }

        private void checkPause3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPause3.Checked == true)
            {
                textPause3.Enabled = true;
                textBox13.Enabled = true;
            }
            else
            {
                textPause3.Enabled = false;
                textBox13.Enabled = false;
            }
        }

        private void checkPause4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPause4.Checked == true)
                textPause4.Enabled = true;
            else
                textPause4.Enabled = false;
        }

        private void checkPause5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPause5.Checked == true)
                textPause5.Enabled = true;
            else
                textPause5.Enabled = false;
        }

        private void checkPause6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPause6.Checked == true)
                textPause6.Enabled = true;
            else
                textPause6.Enabled = false;
        }

        private void checkPause7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkPause7.Checked == true)
                textPause7.Enabled = true;
            else
                textPause7.Enabled = false;
        }




        



    }

    public class DialogData
    {
        public uint type;    //0 = Text, Other = Control Code
        public string text;  //If type is text, this is the dialog text
        //If type is Control Code, this is the Control Code Description
        public int associatedDlg; //Dialog # (0 to n-1) associated with this text draw
    }

    public class textPointer_Type
    {
        public int pointerNum;
        public uint ScriptOffset;
        public uint DlgTextOffset;

        public string dlgHdr;
        public string lkupStr;
        public int numDialogs;
        public List<DialogData> dlogData = new List<DialogData>();
    }
}
