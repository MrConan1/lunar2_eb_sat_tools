﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.load_button = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.save_button = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.insert_before = new System.Windows.Forms.Button();
            this.delete_row_button = new System.Windows.Forms.Button();
            this.insert_after = new System.Windows.Forms.Button();
            this.next_button = new System.Windows.Forms.Button();
            this.prev_button = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.portraitText = new System.Windows.Forms.TextBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.optionsText = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textPause4 = new System.Windows.Forms.TextBox();
            this.textPause5 = new System.Windows.Forms.TextBox();
            this.textPause6 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textPause1 = new System.Windows.Forms.TextBox();
            this.textPause2 = new System.Windows.Forms.TextBox();
            this.textPause3 = new System.Windows.Forms.TextBox();
            this.textPause7 = new System.Windows.Forms.TextBox();
            this.checkPause1 = new System.Windows.Forms.CheckBox();
            this.checkPause2 = new System.Windows.Forms.CheckBox();
            this.checkPause3 = new System.Windows.Forms.CheckBox();
            this.checkPause6 = new System.Windows.Forms.CheckBox();
            this.checkPause5 = new System.Windows.Forms.CheckBox();
            this.checkPause4 = new System.Windows.Forms.CheckBox();
            this.checkPause7 = new System.Windows.Forms.CheckBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.animationText1 = new System.Windows.Forms.TextBox();
            this.animationText2 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.itemBox = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.dlogNum = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Info;
            this.textBox1.Location = new System.Drawing.Point(721, 612);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(370, 26);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(696, 70);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(960, 300);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            this.pictureBox1.Paint += new System.Windows.Forms.PaintEventHandler(this.PictureBox1_Paint);
            // 
            // load_button
            // 
            this.load_button.Location = new System.Drawing.Point(54, 712);
            this.load_button.Name = "load_button";
            this.load_button.Size = new System.Drawing.Size(140, 56);
            this.load_button.TabIndex = 3;
            this.load_button.Text = "Load New File";
            this.load_button.UseVisualStyleBackColor = true;
            this.load_button.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(696, 38);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(126, 26);
            this.textBox2.TabIndex = 4;
            this.textBox2.Text = "Rendered Text";
            // 
            // save_button
            // 
            this.save_button.Location = new System.Drawing.Point(200, 712);
            this.save_button.Name = "save_button";
            this.save_button.Size = new System.Drawing.Size(140, 56);
            this.save_button.TabIndex = 5;
            this.save_button.Text = "Save Script";
            this.save_button.UseVisualStyleBackColor = true;
            this.save_button.Click += new System.EventHandler(this.save_button_Click);
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(1054, 482);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(285, 44);
            this.textBox3.TabIndex = 6;
            this.textBox3.Text = "Dialog Text Entry";
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // insert_before
            // 
            this.insert_before.Location = new System.Drawing.Point(696, 376);
            this.insert_before.Name = "insert_before";
            this.insert_before.Size = new System.Drawing.Size(140, 56);
            this.insert_before.TabIndex = 7;
            this.insert_before.Text = "Insert Before";
            this.insert_before.UseVisualStyleBackColor = true;
            this.insert_before.Click += new System.EventHandler(this.insert_before_Click);
            // 
            // delete_row_button
            // 
            this.delete_row_button.Location = new System.Drawing.Point(842, 376);
            this.delete_row_button.Name = "delete_row_button";
            this.delete_row_button.Size = new System.Drawing.Size(140, 56);
            this.delete_row_button.TabIndex = 8;
            this.delete_row_button.Text = "Delete";
            this.delete_row_button.UseVisualStyleBackColor = true;
            this.delete_row_button.Click += new System.EventHandler(this.delete_button_Click);
            // 
            // insert_after
            // 
            this.insert_after.Location = new System.Drawing.Point(988, 376);
            this.insert_after.Name = "insert_after";
            this.insert_after.Size = new System.Drawing.Size(140, 56);
            this.insert_after.TabIndex = 10;
            this.insert_after.Text = "Insert After";
            this.insert_after.UseVisualStyleBackColor = true;
            this.insert_after.Click += new System.EventHandler(this.insert_after_Click);
            // 
            // next_button
            // 
            this.next_button.Location = new System.Drawing.Point(1516, 376);
            this.next_button.Name = "next_button";
            this.next_button.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.next_button.Size = new System.Drawing.Size(140, 56);
            this.next_button.TabIndex = 11;
            this.next_button.Text = "Next";
            this.next_button.UseVisualStyleBackColor = true;
            this.next_button.Click += new System.EventHandler(this.next_button_Click);
            // 
            // prev_button
            // 
            this.prev_button.Location = new System.Drawing.Point(1359, 376);
            this.prev_button.Name = "prev_button";
            this.prev_button.Size = new System.Drawing.Size(140, 56);
            this.prev_button.TabIndex = 12;
            this.prev_button.Text = "Prev";
            this.prev_button.UseVisualStyleBackColor = true;
            this.prev_button.Click += new System.EventHandler(this.prev_button_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Location = new System.Drawing.Point(346, 712);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(236, 103);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Control Code Mode";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Checked = true;
            this.radioButton2.Location = new System.Drawing.Point(21, 31);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(180, 24);
            this.radioButton2.TabIndex = 1;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "PSX Ctrl Code Mode";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(21, 65);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(196, 24);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.Text = "Saturn Ctrl Code Mode";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Location = new System.Drawing.Point(54, 39);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(449, 624);
            this.listBox1.TabIndex = 15;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.Info;
            this.textBox4.Location = new System.Drawing.Point(721, 657);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(370, 26);
            this.textBox4.TabIndex = 16;
            this.textBox4.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.Info;
            this.textBox5.Location = new System.Drawing.Point(721, 702);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(370, 26);
            this.textBox5.TabIndex = 17;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox6.Location = new System.Drawing.Point(643, 612);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(57, 26);
            this.textBox6.TabIndex = 18;
            this.textBox6.Text = "Line 1";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox7.Location = new System.Drawing.Point(643, 657);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(57, 26);
            this.textBox7.TabIndex = 19;
            this.textBox7.Text = "Line 2";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox8.Location = new System.Drawing.Point(643, 702);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(57, 26);
            this.textBox8.TabIndex = 20;
            this.textBox8.Text = "Line 3";
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox9.Location = new System.Drawing.Point(643, 562);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(57, 26);
            this.textBox9.TabIndex = 21;
            this.textBox9.Text = "Portrait";
            // 
            // portraitText
            // 
            this.portraitText.BackColor = System.Drawing.SystemColors.Info;
            this.portraitText.Location = new System.Drawing.Point(721, 562);
            this.portraitText.Name = "portraitText";
            this.portraitText.Size = new System.Drawing.Size(78, 26);
            this.portraitText.TabIndex = 22;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Location = new System.Drawing.Point(1696, 613);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(110, 24);
            this.checkBox1.TabIndex = 23;
            this.checkBox1.Text = "Linefeed 1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Enabled = false;
            this.checkBox2.Location = new System.Drawing.Point(1695, 659);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(110, 24);
            this.checkBox2.TabIndex = 24;
            this.checkBox2.Text = "Linefeed 2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Enabled = false;
            this.checkBox3.Location = new System.Drawing.Point(1695, 704);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(110, 24);
            this.checkBox3.TabIndex = 25;
            this.checkBox3.Text = "Linefeed 3";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(1695, 744);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(127, 24);
            this.checkBox4.TabIndex = 26;
            this.checkBox4.Text = "Press Button";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // optionsText
            // 
            this.optionsText.BackColor = System.Drawing.SystemColors.Info;
            this.optionsText.Enabled = false;
            this.optionsText.Location = new System.Drawing.Point(757, 483);
            this.optionsText.Name = "optionsText";
            this.optionsText.Size = new System.Drawing.Size(79, 26);
            this.optionsText.TabIndex = 28;
            this.optionsText.Text = "No";
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox12.Location = new System.Drawing.Point(643, 483);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(108, 26);
            this.textBox12.TabIndex = 27;
            this.textBox12.Text = "Option Box?";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.Info;
            this.textBox10.Enabled = false;
            this.textBox10.Location = new System.Drawing.Point(1224, 613);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(370, 26);
            this.textBox10.TabIndex = 29;
            this.textBox10.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.Info;
            this.textBox11.Enabled = false;
            this.textBox11.Location = new System.Drawing.Point(1224, 659);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(370, 26);
            this.textBox11.TabIndex = 30;
            this.textBox11.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // textBox13
            // 
            this.textBox13.BackColor = System.Drawing.SystemColors.Info;
            this.textBox13.Enabled = false;
            this.textBox13.Location = new System.Drawing.Point(1224, 702);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(370, 26);
            this.textBox13.TabIndex = 31;
            this.textBox13.TextChanged += new System.EventHandler(this.textBox13_TextChanged);
            // 
            // textBox15
            // 
            this.textBox15.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox15.Location = new System.Drawing.Point(1601, 785);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(88, 26);
            this.textBox15.TabIndex = 32;
            this.textBox15.Text = "Post Pause";
            // 
            // textPause4
            // 
            this.textPause4.BackColor = System.Drawing.SystemColors.Info;
            this.textPause4.Enabled = false;
            this.textPause4.Location = new System.Drawing.Point(1626, 612);
            this.textPause4.Name = "textPause4";
            this.textPause4.Size = new System.Drawing.Size(60, 26);
            this.textPause4.TabIndex = 34;
            // 
            // textPause5
            // 
            this.textPause5.BackColor = System.Drawing.SystemColors.Info;
            this.textPause5.Enabled = false;
            this.textPause5.Location = new System.Drawing.Point(1626, 659);
            this.textPause5.Name = "textPause5";
            this.textPause5.Size = new System.Drawing.Size(60, 26);
            this.textPause5.TabIndex = 35;
            // 
            // textPause6
            // 
            this.textPause6.BackColor = System.Drawing.SystemColors.Info;
            this.textPause6.Enabled = false;
            this.textPause6.Location = new System.Drawing.Point(1626, 702);
            this.textPause6.Name = "textPause6";
            this.textPause6.Size = new System.Drawing.Size(60, 26);
            this.textPause6.TabIndex = 36;
            // 
            // textBox19
            // 
            this.textBox19.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox19.Location = new System.Drawing.Point(1583, 562);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(96, 26);
            this.textBox19.TabIndex = 37;
            this.textBox19.Text = "EOL Pause";
            // 
            // textBox20
            // 
            this.textBox20.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox20.Location = new System.Drawing.Point(1103, 562);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(96, 26);
            this.textBox20.TabIndex = 38;
            this.textBox20.Text = "Mid Pause";
            // 
            // textPause1
            // 
            this.textPause1.BackColor = System.Drawing.SystemColors.Info;
            this.textPause1.Enabled = false;
            this.textPause1.Location = new System.Drawing.Point(1142, 611);
            this.textPause1.Name = "textPause1";
            this.textPause1.Size = new System.Drawing.Size(57, 26);
            this.textPause1.TabIndex = 39;
            // 
            // textPause2
            // 
            this.textPause2.BackColor = System.Drawing.SystemColors.Info;
            this.textPause2.Enabled = false;
            this.textPause2.Location = new System.Drawing.Point(1142, 659);
            this.textPause2.Name = "textPause2";
            this.textPause2.Size = new System.Drawing.Size(57, 26);
            this.textPause2.TabIndex = 40;
            // 
            // textPause3
            // 
            this.textPause3.BackColor = System.Drawing.SystemColors.Info;
            this.textPause3.Enabled = false;
            this.textPause3.Location = new System.Drawing.Point(1142, 703);
            this.textPause3.Name = "textPause3";
            this.textPause3.Size = new System.Drawing.Size(57, 26);
            this.textPause3.TabIndex = 41;
            // 
            // textPause7
            // 
            this.textPause7.BackColor = System.Drawing.SystemColors.Info;
            this.textPause7.Enabled = false;
            this.textPause7.Location = new System.Drawing.Point(1724, 785);
            this.textPause7.Name = "textPause7";
            this.textPause7.Size = new System.Drawing.Size(70, 26);
            this.textPause7.TabIndex = 42;
            // 
            // checkPause1
            // 
            this.checkPause1.AutoSize = true;
            this.checkPause1.Location = new System.Drawing.Point(1111, 614);
            this.checkPause1.Name = "checkPause1";
            this.checkPause1.Size = new System.Drawing.Size(22, 21);
            this.checkPause1.TabIndex = 43;
            this.checkPause1.UseVisualStyleBackColor = true;
            this.checkPause1.CheckedChanged += new System.EventHandler(this.checkPause1_CheckedChanged);
            // 
            // checkPause2
            // 
            this.checkPause2.AutoSize = true;
            this.checkPause2.Location = new System.Drawing.Point(1111, 661);
            this.checkPause2.Name = "checkPause2";
            this.checkPause2.Size = new System.Drawing.Size(22, 21);
            this.checkPause2.TabIndex = 44;
            this.checkPause2.UseVisualStyleBackColor = true;
            this.checkPause2.CheckedChanged += new System.EventHandler(this.checkPause2_CheckedChanged);
            // 
            // checkPause3
            // 
            this.checkPause3.AutoSize = true;
            this.checkPause3.Location = new System.Drawing.Point(1111, 703);
            this.checkPause3.Name = "checkPause3";
            this.checkPause3.Size = new System.Drawing.Size(22, 21);
            this.checkPause3.TabIndex = 45;
            this.checkPause3.UseVisualStyleBackColor = true;
            this.checkPause3.CheckedChanged += new System.EventHandler(this.checkPause3_CheckedChanged);
            // 
            // checkPause6
            // 
            this.checkPause6.AutoSize = true;
            this.checkPause6.Location = new System.Drawing.Point(1599, 703);
            this.checkPause6.Name = "checkPause6";
            this.checkPause6.Size = new System.Drawing.Size(22, 21);
            this.checkPause6.TabIndex = 48;
            this.checkPause6.UseVisualStyleBackColor = true;
            this.checkPause6.CheckedChanged += new System.EventHandler(this.checkPause6_CheckedChanged);
            // 
            // checkPause5
            // 
            this.checkPause5.AutoSize = true;
            this.checkPause5.Location = new System.Drawing.Point(1599, 661);
            this.checkPause5.Name = "checkPause5";
            this.checkPause5.Size = new System.Drawing.Size(22, 21);
            this.checkPause5.TabIndex = 47;
            this.checkPause5.UseVisualStyleBackColor = true;
            this.checkPause5.CheckedChanged += new System.EventHandler(this.checkPause5_CheckedChanged);
            // 
            // checkPause4
            // 
            this.checkPause4.AutoSize = true;
            this.checkPause4.Location = new System.Drawing.Point(1599, 614);
            this.checkPause4.Name = "checkPause4";
            this.checkPause4.Size = new System.Drawing.Size(22, 21);
            this.checkPause4.TabIndex = 46;
            this.checkPause4.UseVisualStyleBackColor = true;
            this.checkPause4.CheckedChanged += new System.EventHandler(this.checkPause4_CheckedChanged);
            // 
            // checkPause7
            // 
            this.checkPause7.AutoSize = true;
            this.checkPause7.Location = new System.Drawing.Point(1695, 787);
            this.checkPause7.Name = "checkPause7";
            this.checkPause7.Size = new System.Drawing.Size(22, 21);
            this.checkPause7.TabIndex = 49;
            this.checkPause7.UseVisualStyleBackColor = true;
            this.checkPause7.CheckedChanged += new System.EventHandler(this.checkPause7_CheckedChanged);
            // 
            // textBox14
            // 
            this.textBox14.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox14.Location = new System.Drawing.Point(822, 562);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(98, 26);
            this.textBox14.TabIndex = 50;
            this.textBox14.Text = "Animations";
            // 
            // animationText1
            // 
            this.animationText1.BackColor = System.Drawing.SystemColors.Info;
            this.animationText1.Enabled = false;
            this.animationText1.Location = new System.Drawing.Point(935, 562);
            this.animationText1.Name = "animationText1";
            this.animationText1.Size = new System.Drawing.Size(73, 26);
            this.animationText1.TabIndex = 51;
            // 
            // animationText2
            // 
            this.animationText2.BackColor = System.Drawing.SystemColors.Info;
            this.animationText2.Enabled = false;
            this.animationText2.Location = new System.Drawing.Point(1025, 562);
            this.animationText2.Name = "animationText2";
            this.animationText2.Size = new System.Drawing.Size(66, 26);
            this.animationText2.TabIndex = 52;
            // 
            // textBox27
            // 
            this.textBox27.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox27.Location = new System.Drawing.Point(1088, 782);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(198, 26);
            this.textBox27.TabIndex = 53;
            this.textBox27.Text = "(Enter all numbers in hex)";
            // 
            // itemBox
            // 
            this.itemBox.BackColor = System.Drawing.SystemColors.Info;
            this.itemBox.Location = new System.Drawing.Point(721, 522);
            this.itemBox.Name = "itemBox";
            this.itemBox.Size = new System.Drawing.Size(78, 26);
            this.itemBox.TabIndex = 55;
            // 
            // textBox17
            // 
            this.textBox17.BackColor = System.Drawing.SystemColors.Menu;
            this.textBox17.Location = new System.Drawing.Point(643, 522);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(57, 26);
            this.textBox17.TabIndex = 54;
            this.textBox17.Text = "Item";
            // 
            // dlogNum
            // 
            this.dlogNum.BackColor = System.Drawing.SystemColors.Info;
            this.dlogNum.Enabled = false;
            this.dlogNum.Location = new System.Drawing.Point(1583, 438);
            this.dlogNum.Name = "dlogNum";
            this.dlogNum.Size = new System.Drawing.Size(73, 26);
            this.dlogNum.TabIndex = 56;
            this.dlogNum.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1820, 825);
            this.Controls.Add(this.dlogNum);
            this.Controls.Add(this.itemBox);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.animationText2);
            this.Controls.Add(this.animationText1);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.checkPause7);
            this.Controls.Add(this.checkPause6);
            this.Controls.Add(this.checkPause5);
            this.Controls.Add(this.checkPause4);
            this.Controls.Add(this.checkPause3);
            this.Controls.Add(this.checkPause2);
            this.Controls.Add(this.checkPause1);
            this.Controls.Add(this.textPause7);
            this.Controls.Add(this.textPause3);
            this.Controls.Add(this.textPause2);
            this.Controls.Add(this.textPause1);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textPause6);
            this.Controls.Add(this.textPause5);
            this.Controls.Add(this.textPause4);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.optionsText);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.checkBox4);
            this.Controls.Add(this.checkBox3);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.portraitText);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.prev_button);
            this.Controls.Add(this.next_button);
            this.Controls.Add(this.insert_after);
            this.Controls.Add(this.delete_row_button);
            this.Controls.Add(this.insert_before);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.save_button);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.load_button);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "L2 Dialog Editor";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button load_button;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button save_button;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button insert_before;
        private System.Windows.Forms.Button delete_row_button;
        private System.Windows.Forms.Button insert_after;
        private System.Windows.Forms.Button next_button;
        private System.Windows.Forms.Button prev_button;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox portraitText;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.TextBox optionsText;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textPause4;
        private System.Windows.Forms.TextBox textPause5;
        private System.Windows.Forms.TextBox textPause6;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textPause1;
        private System.Windows.Forms.TextBox textPause2;
        private System.Windows.Forms.TextBox textPause3;
        private System.Windows.Forms.TextBox textPause7;
        private System.Windows.Forms.CheckBox checkPause1;
        private System.Windows.Forms.CheckBox checkPause2;
        private System.Windows.Forms.CheckBox checkPause3;
        private System.Windows.Forms.CheckBox checkPause6;
        private System.Windows.Forms.CheckBox checkPause5;
        private System.Windows.Forms.CheckBox checkPause4;
        private System.Windows.Forms.CheckBox checkPause7;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox animationText1;
        private System.Windows.Forms.TextBox animationText2;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox itemBox;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox dlogNum;
    }
}

